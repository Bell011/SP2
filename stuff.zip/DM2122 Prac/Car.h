#pragma once
class Car
{
private:
	float acceleration;
};

