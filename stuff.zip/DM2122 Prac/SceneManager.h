#pragma once
#include <vector>
#include "Scene"
class SceneManager
{
	std::Scene <vector>
};

