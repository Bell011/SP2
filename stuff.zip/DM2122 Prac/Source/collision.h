#ifndef COLLISION_H
#define COLLISION_H
#include "Vector3.h"
#include "collcorners.h"
//class AABBobj {
//	private:
//	Vector3 size;
//	Vector3 pos;
//	public:
//	AABBobj(Vector3 size = Vector3(1,1,1), Vector3 pos = Vector3(0,0,0)){ 
//		this->size = size;
//		this->pos = pos;
//	}
//	void setSize(corners& c) {
//		size = Vector3(c.getMax().x-c.getMin().x, c.getMax().y - c.getMin().y, c.getMax().z - c.getMin().z);
//	}
//	void setManualSize(Vector3 s) {
//		size = s;
//	}
//	void setPos(Vector3 p) {
//		pos = p;
//	}
//	Vector3 getPos() {
//		return pos;
//	}
//	Vector3 getSize() {
//		return size;
//	}
//};

#endif